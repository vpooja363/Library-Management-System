import random

def generate_member_id():
    return str(random.randint(1000, 9999))